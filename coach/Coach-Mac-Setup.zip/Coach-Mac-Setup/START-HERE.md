# Coach

For Apple silicon Macs running macOS 13 or later, with PopClip 2026.7 or later.

## Set up another Mac

1. Copy **Coach.app** to Applications and open it once.
2. Open **Coach.popclipextz** to install the Coach button in PopClip.
3. Open Coach Settings, enter your OpenAI API key, and click **Save settings**.
4. Sync your dotfiles checkout to `~/dotfiles`, then click **Use dotfiles config** in Coach Settings.

Select English or Chinese text and click **Coach** for an explanation or writing feedback. Use **Pronounce** to hear it.

The model and learning prompt are read from and saved to **~/dotfiles/coach/config/settings.json**. Each save updates this single file. Sync this folder between Macs using your dotfiles workflow, then open Coach or click **Refresh** to load changes. Coach does not push or pull Git changes. API keys stay in each Mac’s Keychain; conversations are not saved.

Place Coach first in the PopClip menu on each Mac.

When upgrading, quit the old app and replace it with Coach.app. Keep only one installed copy. Existing settings and API keys are retained.

The app is locally signed, not notarized; macOS may ask you to approve opening it.

See **UPDATE-HISTORY.md** for changes in each version.
