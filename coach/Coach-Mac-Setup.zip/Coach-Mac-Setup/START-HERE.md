# Coach

For Apple silicon Macs running macOS 13 or later, with PopClip 2026.7 or later.

## Setup

1. Copy **Coach.app** to Applications and open it once.
2. Open **Coach.popclipextz** to install the Coach button in PopClip.
3. Click the gear in Coach, expand **API connection**, choose OpenAI or OpenRouter, enter your model ID and API key, and click **Save changes**.

Model ID examples: `gpt-4.1-mini` for OpenAI; `openai/gpt-4.1-mini` for OpenRouter. Your existing OpenAI model and key are retained. Each provider keeps its own model and key. **Test connection** sends a small test request and may incur API charges.

Select English or Chinese text and click Coach. Coach explains or rewrites the language; it does not carry out commands in the text. Explanations are detailed, with advanced vocabulary explained and Chinese support. Word explanations show US and UK IPA with separate speaker buttons. Select answer text to reveal US/UK speech controls for that selection.

## Launch at login

Keep Coach.app in Applications. Open the gear, enable **Launch at login**, and click **Save changes**. If macOS requests approval, click **Open Login Items** and allow Coach. Turn the setting off and save to disable automatic startup. This setting is per Mac and managed by macOS.

## Learning and history

The gear opens editable coaching instructions in the same popup. Save applies edits; Cancel discards them. **Restore default** restores the bundled instructions. Fixed learning-only rules and detailed bilingual coaching still apply.

The clock opens local coaching history. Search, reopen, delete, or export all saved entries as JSON for learning-gap analysis. Exports include original text, answers, provider/model, timestamps, and the exact instructions used, but no API keys. Review content before sharing. Quoted input and lookups do not necessarily indicate your own mistakes.

Turning **Save history** off keeps existing entries. Only completed responses are saved. History lives in `~/Library/Application Support/Coach/history.json`. Settings and history stay on each Mac; keys stay in macOS Keychain. Nothing is synced through iCloud. Existing legacy iCloud settings are ignored.

## Upgrade

Quit Coach before replacing it. Keep only one installed copy. Local settings, credentials, history, and edited instructions are retained. If you want the latest bundled instructions after an update, use **Restore default** and save.

Place Coach first in the PopClip menu on each Mac. The app is locally signed, not notarized; macOS may ask you to approve opening it.

See **UPDATE-HISTORY.md** for changes in each version.
