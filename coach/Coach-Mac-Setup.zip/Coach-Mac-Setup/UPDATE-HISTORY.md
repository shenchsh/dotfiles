# 1.2.8

- Store shared model and instructions in `~/dotfiles/coach/config/settings.json` instead of iCloud Drive.

# Coach update history

Newest version first. Install updates by quitting Coach and replacing the app in Applications. Open the included PopClip extension to update its action.

## 1.2.7
- Treat all submitted text as material to explain or rewrite, including commands and questions.
- Remove conflicting prompt instructions that allowed Coach to carry out requests in the input.
- Verified that “generate a sample report” receives wording feedback instead of report-generation questions.

## 1.2.6
- Explain possible causes of important writing mistakes, with correction patterns, contrasting examples, and brief practice cues.
- Distinguish supported observations from guesses about the learner; separate errors from optional style changes.

## 1.2.5
- Explicitly require “Why these changes” for every rewrite, including single sentences.

## 1.2.4
- Use a shared structure for words and expressions: Explain it, Use it, Extend it, Remember it.
- Combine English meaning and Chinese explanation under Explain it.
- Add IPA for words, similar and contrasting vocabulary, reliable origins, and memory cues.

## 1.2.3
- Add separate learning structures for words and expressions, with practical patterns, connections, and recall cues.

## 1.2.2
- Refocus the prompt on understanding, natural usage, and remembering.
- Place the Chinese explanation immediately after the English meaning; include useful, reliable origins.

## 1.2.1
- Add a brief Chinese explanation to English-first explanation answers.

## 1.2
- Keep shared settings in one file: iCloud Drive/Sync/Config/Coach/settings.json.
- Consolidate older revisions and resolve iCloud conflicts using the newest settings timestamp.

## 1.1.3
- Add the custom teal Coach app icon.

## 1.1.2
- Move configuration sync to iCloud Drive/Sync/Config/Coach and migrate existing settings.
- Show prominent errors for missing API keys, invalid input, and request failures.
- Add PopClip guidance when the app cannot open.

## 1.1.1
- Rename the app and extension to Coach.
- Distribute an Apple silicon-only build with focused setup instructions.

## 1.1
- Add multi-Mac model and prompt synchronization through iCloud Drive.
- Keep API keys in each Mac’s Keychain.
- Introduce a portable setup package; this version included both Apple silicon and Intel builds.

## 1.0
- Initial packaged release of the floating Coach app with PopClip integration.
- English-first explanations and structure-preserving rewrites for English, Chinese, and mixed input.
- Markdown rendering, local pronunciation, editable learning instructions, and Keychain API-key storage.
